import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import si from "systeminformation";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Gemini Initialization
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", version: "1.0.0-JARVIS" });
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const { message, history } = req.body;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          { role: "user", parts: [{ text: `You are JARVIS, a hyper-advanced AI assistant inspired by Iron Man's JARVIS. 
            You are intelligent, calm, confident, and slightly witty. Your responses should be concise and cinematic.
            Address the user as "Sir" or "Ma'am" when appropriate.
            The current system status is being monitored separately.
            User Message: ${message}` }]},
          ...(history || []).map((h: any) => ({
            role: h.role,
            parts: [{ text: h.text }]
          }))
        ],
        config: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
        }
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: "Failed to communicate with JARVIS core." });
    }
  });

  app.get("/api/stats", async (req, res) => {
    try {
      const [cpu, mem, battery, network, temp] = await Promise.all([
        si.currentLoad(),
        si.mem(),
        si.battery(),
        si.networkStats(),
        si.cpuTemperature(),
      ]);

      res.json({
        cpu: cpu.currentLoad.toFixed(1),
        memory: ((mem.active / mem.total) * 100).toFixed(1),
        battery: battery.hasBattery ? battery.percent : null,
        network: network[0]?.operstate || "active",
        temp: temp.main || null, 
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch telemetry." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`JARVIS Operational on http://0.0.0.0:${PORT}`);
  });
}

startServer();
