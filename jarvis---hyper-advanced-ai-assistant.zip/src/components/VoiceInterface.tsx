import React, { useState, useRef, useEffect } from "react";
import { Mic, Send, Terminal as TerminalIcon } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface Message {
  role: 'user' | 'assistant';
  text: string;
}

export const VoiceInterface: React.FC = () => {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (text: string) => {
    if (!text.trim()) return;
    
    const userMsg = { role: 'user' as const, text };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setIsProcessing(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, history: messages.slice(-5) })
      });
      const data = await res.json();
      
      setMessages(prev => [...prev, { role: 'assistant', text: data.text }]);
      
      // Basic TTS Speech
      const utterance = new SpeechSynthesisUtterance(data.text);
      utterance.rate = 1.05;
      utterance.pitch = 0.95;
      window.speechSynthesis.speak(utterance);
      
    } catch (e) {
      setMessages(prev => [...prev, { role: 'assistant', text: "System error: Failed to reach JARVIS core." }]);
    } finally {
      setIsProcessing(false);
    }
  };

  const startListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      handleSend(transcript);
    };

    recognition.start();
  };

  return (
    <div className="w-full z-20">
      {/* Interaction History */}
      <div 
        ref={scrollRef}
        className="mb-4 h-48 overflow-y-auto space-y-3 scrollbar-hide flex flex-col"
      >
        <AnimatePresence mode="popLayout">
          {messages.map((m, i) => (
            <motion.div
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              key={i}
              className={`max-w-[80%] p-3 rounded-lg font-mono text-sm ${
                m.role === 'user' 
                  ? 'bg-cyan-500/10 border border-cyan-500/20 self-end mr-4' 
                  : 'bg-black/40 border border-white/10 self-start ml-4 shadow-[0_4px_20px_rgba(0,0,0,0.5)] text-cyan-300'
              }`}
            >
              <div className="text-[10px] uppercase opacity-50 mb-1">
                {m.role === 'user' ? 'Identity Verified' : 'JARVIS Protocol'}
              </div>
              {m.text}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Input Console */}
      <div className="relative group">
        <div className="absolute inset-0 bg-cyan-500/10 blur-xl opacity-0 group-focus-within:opacity-100 transition-opacity" />
        <div className="relative flex items-center bg-black/80 border border-cyan-500/30 rounded-xl p-2 shadow-2xl backdrop-blur-md">
          <button 
            onClick={startListening}
            className={`p-3 rounded-lg transition-all ${
              isListening ? 'bg-red-500/20 text-red-400 animate-pulse' : 'hover:bg-cyan-500/10 text-cyan-400'
            }`}
          >
            <Mic size={24} />
          </button>
          
          <input 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend(input)}
            placeholder={isProcessing ? "Processing logical nodes..." : "Direct verbal command input..."}
            className="flex-1 bg-transparent border-none focus:ring-0 text-cyan-100 font-mono px-4 placeholder:text-cyan-900 placeholder:italic"
            disabled={isProcessing}
          />
          
          <button 
            onClick={() => handleSend(input)}
            disabled={isProcessing}
            className="p-3 bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 transition-colors rounded-lg"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
      
      {/* Status Bar */}
      <div className="mt-4 flex justify-between px-2">
        <div className="flex items-center space-x-2">
          <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_5px_rgba(34,211,238,1)] animate-pulse" />
          <span className="text-[9px] uppercase tracking-widest text-cyan-600 font-mono">Neural Link: Online</span>
        </div>
        <div className="flex items-center space-x-4">
           <span className="text-[9px] uppercase tracking-widest text-cyan-600 font-mono">Encrypted 512-bit</span>
           <span className="text-[9px] uppercase tracking-widest text-cyan-600 font-mono">Stark OS 14.2</span>
        </div>
      </div>
    </div>
  );
};
