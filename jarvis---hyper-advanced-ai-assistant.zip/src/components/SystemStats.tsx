import React, { useEffect, useState } from "react";
import { Cpu, Database, Battery, Globe, Thermometer } from "lucide-react";

export const SystemStats: React.FC = () => {
  const [stats, setStats] = useState({
    cpu: "0.0",
    memory: "0.0",
    battery: null,
    network: "active",
    temp: null
  });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch("/api/stats");
        const data = await res.json();
        setStats(data);
      } catch (e) {}
    };

    fetchStats();
    const interval = setInterval(fetchStats, 5000);
    return () => clearInterval(interval);
  }, []);

  const StatItem = ({ icon: Icon, label, value, unit }: any) => (
    <div className="flex items-center space-x-4 p-4 border-l-2 border-cyan-500/30 bg-cyan-500/5 group hover:bg-cyan-500/10 transition-colors">
      <div className="p-2 bg-cyan-500/10 text-cyan-400">
        <Icon size={18} />
      </div>
      <div>
        <p className="text-[10px] uppercase tracking-widest text-cyan-400/60 font-mono">{label}</p>
        <p className="text-lg font-mono text-cyan-300 glow-text-cyan">
          {value}{unit}
        </p>
      </div>
    </div>
  );

  return (
    <div className="space-y-3 z-10">
      <StatItem icon={Cpu} label="CPU LOAD" value={stats.cpu} unit="%" />
      <StatItem icon={Database} label="MEMORY USE" value={stats.memory} unit="%" />
      <StatItem icon={Battery} label="POWER CELL" value={stats.battery ?? "100"} unit="%" />
      {stats.temp && <StatItem icon={Thermometer} label="THERMALS" value={stats.temp} unit="°C" />}
      <StatItem icon={Globe} label="NET CORE" value={stats.network} unit="" />
    </div>
  );
};
