import React, { useRef, useState, useCallback } from "react";
import Webcam from "react-webcam";
import { Camera, RefreshCcw, Search } from "lucide-react";
import { motion } from "motion/react";

export const VisionPanel: React.FC = () => {
  const webcamRef = useRef<Webcam>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [objects, setObjects] = useState<string[]>([]);

  const capture = useCallback(() => {
    setAnalyzing(true);
    // Simulate object detection
    setTimeout(() => {
      setObjects(["Humanoid Presence", "Biometric Signature Detected", "Environment: Stable"]);
      setAnalyzing(false);
    }, 2000);
  }, []);

  return (
    <div className="w-full z-10 space-y-4">
      <div className="relative aspect-video rounded overflow-hidden border border-cyan-500/30 bg-black group">
        <Webcam
          audio={false}
          ref={webcamRef}
          screenshotFormat="image/jpeg"
          className="w-full h-full object-cover grayscale opacity-60 group-hover:opacity-100 transition-opacity"
          disablePictureInPicture={true}
          forceScreenshotSourceSize={false}
          imageSmoothing={true}
          mirrored={false}
          onUserMedia={() => {}}
          onUserMediaError={() => {}}
          onScreenshots={() => {}}
          videoConstraints={{ facingMode: "user" }}
        />
        
        {/* Visual Overlays */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-4 left-4 w-4 h-4 border-t-2 border-l-2 border-cyan-400" />
          <div className="absolute top-4 right-4 w-4 h-4 border-t-2 border-r-2 border-cyan-400" />
          <div className="absolute bottom-4 left-4 w-4 h-4 border-b-2 border-l-2 border-cyan-400" />
          <div className="absolute bottom-4 right-4 w-4 h-4 border-b-2 border-r-2 border-cyan-400" />
          
          <motion.div 
            animate={{ top: ["0%", "100%", "0%"] }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            className="absolute left-0 right-0 h-0.5 bg-cyan-400/50 shadow-[0_0_10px_rgba(34,211,238,0.5)]"
          />
        </div>

        {analyzing && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm">
            <RefreshCcw className="animate-spin text-cyan-400" size={24} />
          </div>
        )}
      </div>

      <div className="p-3 bg-cyan-500/5 border border-cyan-500/30 rounded-sm">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-[10px] font-mono uppercase tracking-[0.2em] text-cyan-400">Vision Diagnostics</h3>
          <button 
            onClick={capture}
            className="p-1 hover:bg-cyan-500/20 text-cyan-400 transition-colors rounded"
          >
            <Search size={14} />
          </button>
        </div>
        
        <div className="space-y-1">
          {objects.map((obj, i) => (
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              key={i}
              className="text-[9px] font-mono text-cyan-300/80 flex items-center space-x-2"
            >
              <div className="w-1 h-1 bg-cyan-400 rounded-full" />
              <span>{obj}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
