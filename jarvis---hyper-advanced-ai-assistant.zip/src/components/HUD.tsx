import React from "react";
import { motion } from "motion/react";

export const HolographicBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 hologram-grid opacity-20" />
      
      {/* Scanline Animation */}
      <div className="scanline" />
      
      {/* Radial Vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.8)_100%)]" />
      
      {/* Ambient Glows */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 blur-[120px] rounded-full" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 blur-[120px] rounded-full" />
    </div>
  );
};

export const ArcReactor: React.FC = () => {
  return (
    <div className="relative w-64 h-64 flex items-center justify-center">
      {/* Inner Core */}
      <motion.div 
        animate={{ scale: [1, 1.05, 1], opacity: [0.8, 1, 0.8] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="absolute w-24 h-24 rounded-full bg-cyan-400/20 border-2 border-cyan-400/50 shadow-[0_0_30px_rgba(34,211,238,0.5)] flex items-center justify-center"
      >
        <div className="w-16 h-16 rounded-full border border-cyan-400/30 flex items-center justify-center">
          <div className="w-4 h-4 rounded-full bg-white shadow-[0_0_15px_#fff]" />
        </div>
      </motion.div>

      {/* Rotating Rings */}
      <div className="absolute inset-0 border-4 border-cyan-500/10 rounded-full" />
      
      <motion.div 
        className="absolute w-full h-full border-t-2 border-cyan-400 rounded-full opacity-40 animate-rotate-slow"
      />
      
      <motion.div 
        className="absolute w-[85%] h-[85%] border-b-2 border-dashed border-cyan-400 rounded-full opacity-30 animate-rotate-slow-reverse"
      />

      <div className="absolute w-[70%] h-[70%] border-l-2 border-cyan-400/20 rounded-full" />
      
      {/* Compass Marks */}
      {[...Array(8)].map((_, i) => (
        <div 
          key={i}
          className="absolute w-1 h-3 bg-cyan-400/50"
          style={{ 
            transform: `rotate(${i * 45}deg) translateY(-110px)` 
          }}
        />
      ))}
    </div>
  );
};
