import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { HolographicBackground, ArcReactor } from "./components/HUD";
import { SystemStats } from "./components/SystemStats";
import { VisionPanel } from "./components/VisionPanel";
import { VoiceInterface } from "./components/VoiceInterface";
import { Terminal as TerminalIcon, ShieldCheck, Activity } from "lucide-react";

export default function App() {
  const [bootStatus, setBootStatus] = useState<string[]>([]);
  const [isBooted, setIsBooted] = useState(false);
  const [showHUD, setShowHUD] = useState(false);

  useEffect(() => {
    const sequences = [
      "Initializing Neural Core...",
      "Connecting to Stark Satellite Network...",
      "Loading Biometric Protocols...",
      "Syncing Local Telemetry...",
      "Neural Link Established.",
      "Good Afternoon, Sir."
    ];

    let current = 0;
    const interval = setInterval(() => {
      if (current < sequences.length) {
        setBootStatus(prev => [...prev, sequences[current]]);
        current++;
      } else {
        clearInterval(interval);
        setTimeout(() => setIsBooted(true), 1000);
        setTimeout(() => setShowHUD(true), 2000);
      }
    }, 800);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative min-h-screen bg-black text-cyan-400 font-sans selection:bg-cyan-500/30 selection:text-cyan-100 uppercase select-none">
      <HolographicBackground />

      <AnimatePresence>
        {!isBooted && (
          <motion.div 
            exit={{ opacity: 0, scale: 1.1 }}
            className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black"
          >
            <ArcReactor />
            <div className="mt-12 w-64 space-y-2">
              {bootStatus.map((status, i) => (
                <motion.p 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={i}
                  className="text-[10px] font-mono tracking-widest text-cyan-500"
                >
                  <span className="mr-2 text-cyan-300">{">"}</span>
                  {status}
                </motion.p>
              ))}
            </div>
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: "200px" }}
              transition={{ duration: 4.8 }}
              className="mt-8 h-0.5 bg-cyan-500 shadow-[0_0_10px_rgba(34,211,238,1)]"
            />
          </motion.div>
        )}
      </AnimatePresence>

      <motion.main 
        initial={{ opacity: 0 }}
        animate={{ opacity: showHUD ? 1 : 0 }}
        className="relative z-10 p-4 h-screen flex flex-col pointer-events-none"
      >
        {/* Top Header */}
        <header className="flex justify-between items-end border-b border-cyan-800/50 pb-2 mb-4 pointer-events-auto">
          <div className="flex flex-col">
            <span className="text-[10px] tracking-[0.3em] text-cyan-600 font-bold uppercase">System Identity</span>
            <h1 className="text-4xl font-black tracking-tighter leading-none flex items-center">
              J.A.R.V.I.S.<span className="ml-3 px-2 py-0.5 text-xs bg-cyan-500 text-slate-950 rounded font-bold">V 4.0.2</span>
            </h1>
          </div>
          <div className="flex gap-8 text-right">
            <div className="flex flex-col">
              <span className="text-[10px] tracking-widest text-cyan-600 uppercase">Status</span>
              <span className="font-mono text-sm text-green-400 font-bold italic">ENCRYPTED</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] tracking-widest text-cyan-600 uppercase">System Time</span>
              <span className="font-mono text-2xl leading-none glow-text-cyan uppercase">
                {new Date().toLocaleTimeString('en-US', { hour12: false })}
              </span>
            </div>
          </div>
        </header>

        {/* High Density Grid */}
        <div className="flex-1 grid grid-cols-12 gap-4 min-h-0 pointer-events-auto">
          {/* Left Column: Vision */}
          <aside className="col-span-3 flex flex-col gap-4">
            <div className="flex-1 bg-slate-900/40 border border-cyan-900/50 p-3 rounded-sm flex flex-col overflow-hidden">
               <h3 className="text-xs font-bold text-cyan-700 uppercase tracking-widest mb-3 border-l-2 border-cyan-500 pl-2">Local Environment</h3>
               <VisionPanel />
            </div>
          </aside>

          {/* Center Column: Core & Voice */}
          <main className="col-span-6 flex flex-col items-center justify-between relative py-8">
            <div className="flex-1 flex flex-col items-center justify-center relative w-full">
              <div className="absolute w-96 h-96 border-2 border-cyan-500/10 rounded-full flex items-center justify-center pointer-events-none">
                <div className="absolute w-[110%] h-[110%] border border-cyan-500/5 rounded-full border-dashed animate-rotate-slow"></div>
                <div className="w-80 h-80 border border-cyan-400/30 rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(34,211,238,0.1)]">
                  <ArcReactor />
                </div>
              </div>
            </div>

            <div className="w-full mt-auto">
              <VoiceInterface />
            </div>
          </main>

          {/* Right Column: Telemetry */}
          <aside className="col-span-3 flex flex-col gap-4">
            <div className="flex-1 bg-slate-900/40 border border-cyan-900/50 p-3 rounded-sm flex flex-col">
              <h3 className="text-xs font-bold text-cyan-700 uppercase tracking-widest mb-3 border-r-2 border-cyan-500 pr-2 text-right">System Telemetry</h3>
              <SystemStats />
            </div>
          </aside>
        </div>

        {/* Global Footer (Console) */}
        <footer className="h-32 bg-slate-900/60 border-t border-cyan-800/30 mt-4 p-3 font-mono pointer-events-auto relative">
          <div className="absolute top-0 left-4 -translate-y-1/2 bg-slate-950 px-2 text-[10px] text-cyan-500 uppercase tracking-widest">Console Diagnostics</div>
          <div className="h-full overflow-y-auto text-[10px] leading-relaxed text-cyan-200/60 scrollbar-hide">
            <div className="flex gap-2 text-cyan-400"><span className="text-white">[{new Date().toLocaleTimeString()}]</span> <span className="text-green-400 italic">INFO:</span> Neural Bridge Stable.</div>
            <div className="flex gap-2"><span className="text-white">[{new Date().toLocaleTimeString()}]</span> JARVIS_OS_CORE running at 102.4 GFLOPs.</div>
            <div className="flex gap-2 text-amber-400"><span className="text-white">[{new Date().toLocaleTimeString()}]</span> <span className="text-amber-500 italic">WARN:</span> External relay interference filtered.</div>
            <div className="flex gap-2 animate-pulse text-cyan-400">{" > "} Listening for verbal authentication... <span className="w-2 h-3 bg-cyan-400 ml-1"></span></div>
          </div>
        </footer>
      </motion.main>

      {/* Background Ambience Layers (Overlays) */}
      <div className="fixed inset-0 pointer-events-none z-40 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-overlay" />
    </div>
  );
}
